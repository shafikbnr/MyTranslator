package com.shafi.voicetranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface
import android.text.method.ScrollingMovementMethod
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var language: Spinner
    private lateinit var original: TextView
    private lateinit var translated: TextView
    private lateinit var listen: Button
    private lateinit var status: TextView
    private val requestCode = 401
    private var target = "ta"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val pad = 22
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.TOP
        }
        val heading = TextView(this).apply {
            text = "Shafi Voice Translator"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
        }
        layout.addView(heading)
        layout.addView(TextView(this).apply {
            text = "Speak Malayalam → get Tamil or Hindi in English letters"
            textSize = 14f
            setPadding(0, 8, 0, 18)
        })
        language = Spinner(this)
        language.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Tamil", "Hindi"))
        language.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                target = if (position == 0) "ta" else "hi"
            }
        }
        layout.addView(language)
        listen = Button(this).apply {
            text = "🎙 Speak Malayalam"
            setOnClickListener { startListening() }
        }
        layout.addView(listen)
        status = TextView(this).apply { text = "Ready"; setPadding(0, 8, 0, 12) }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "Your Malayalam"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        })
        original = makeResultText()
        layout.addView(original)
        layout.addView(TextView(this).apply {
            text = "Translation (English letters)"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 16, 0, 0)
        })
        translated = makeResultText()
        layout.addView(translated)
        layout.addView(Button(this).apply {
            text = "Copy translation"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Translation", translated.text))
                Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun makeResultText() = TextView(this).apply {
        text = "—"
        textSize = 19f
        setPadding(12, 12, 12, 12)
        movementMethod = ScrollingMovementMethod()
        setBackgroundColor(0xFFF1F1F1.toInt())
        minHeight = 90
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition service is not available on this phone."
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCode)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ml-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ml-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in Malayalam")
        }
        try { startActivityForResult(intent, requestCode) }
        catch (e: Exception) { status.text = "Could not start speech recognition: ${e.message}" }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = words?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                original.text = spoken
                translated.text = "Translating…"
                status.text = "Translating"
                Thread {
                    val result = translate(spoken, target)
                    runOnUiThread {
                        translated.text = result ?: "Translation failed. Check internet and try again."
                        status.text = "Done"
                    }
                }.start()
            }
        }
    }

    private fun translate(text: String, lang: String): String? {
        return try {
            val q = URLEncoder.encode(text, "UTF-8")
            val url = URL("https://api.mymemory.translated.net/get?q=$q&langpair=ml|$lang")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 15000
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val translatedText = JSONObject(body).getJSONObject("responseData").getString("translatedText")
            transliterate(translatedText, lang)
        } catch (_: Exception) { null }
    }

    private fun transliterate(value: String, lang: String): String {
        val transliteratorId = if (lang == "ta") "Tamil-Latin; Latin-ASCII" else "Devanagari-Latin; Latin-ASCII"
        return try {
            val clazz = Class.forName("android.icu.text.Transliterator")
            val getInstance = clazz.getMethod("getInstance", String::class.java)
            val transliterator = getInstance.invoke(null, transliteratorId)
            transliterator.javaClass.getMethod("transliterate", String::class.java).invoke(transliterator, value) as String
        } catch (_: Exception) { value }
    }
}
