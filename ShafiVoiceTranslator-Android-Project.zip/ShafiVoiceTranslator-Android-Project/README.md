# Shafi Voice Translator (Android project)

This is an Android Studio source project, **not a ready-to-install APK**.

## App behavior
- Android 10 (API 29) or later.
- Choose Tamil or Hindi.
- Tap Speak Malayalam and dictate in Malayalam.
- Shows recognized Malayalam and a romanized translation.
- No translation history; each new result replaces the previous one.
- Copy translation button.

## Build
Open this folder in Android Studio, allow Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important limitations
- The project has not been compiled or tested on a physical phone in this environment.
- Speech recognition depends on a speech recognition service installed and configured on the phone.
- Translation uses the public MyMemory API; availability, rate limits, privacy terms, and translation quality are controlled by that service.
- Transliteration produces Latin letters, but may not match natural spoken colloquial Manglish pronunciation.
- A network connection is required for translation.

## Android permissions
The app requests microphone and internet permissions.
